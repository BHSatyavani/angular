import { Component, OnInit } from '@angular/core';
import { ReferService } from '../service/refer.service';

@Component({
  selector: 'app-refer',
  templateUrl: './refer.component.html',
  styleUrls: ['./refer.component.css']
})
export class ReferComponent implements OnInit {
friends:string[]=[];
  constructor(private referService:ReferService) { }

  ngOnInit() {
  }
  getList():void{
    this.referService.getList().subscribe(friends=>{
      this.friends=friends
    })
  }

  onSubmit():void{
    this.getList();
  }


}
